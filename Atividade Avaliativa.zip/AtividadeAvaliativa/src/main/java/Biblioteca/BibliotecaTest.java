
package Biblioteca;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class BibliotecaTest {
    public static void main(String[] args) {
        List<Usuario> usuarios = new ArrayList<>();     
        List<Livros> livros = new ArrayList<>();
        List<Emprestimo> emprestimos = new ArrayList<>();
        
        usuarios.add(new Usuario("Willian", "willian.wow@hotmail.com.br", "123456", 111));
        usuarios.add(new Usuario("Robson", "Robson@hotmail.com", "123987", 222));
        

        livros.add(new Livros("O Silmarillion", "J. R. R. Tolkien", "primeira ediçao", "Christopher Tolkien", "Reino Unido", 1977, 1));
        livros.add(new Livros("Harry Potter e a Pedra Filosofal", "J. K. Rowling", "primeira ediçao", "	Bloomsbury Publishing", "Reino Unido", 1997, 2));
        livros.add(new Livros("O Hobbit", "J. R. R. Tolkien", "primeira ediçao", "George Allen & Unwin", "Reino Unido", 1937, 3));
        
        emprestimos.add(new Emprestimo(157, 1, LocalDate.EPOCH, LocalDate.EPOCH, true, 0));
        emprestimos.add(new Emprestimo(187, 3, LocalDate.EPOCH, LocalDate.EPOCH, true, 0));
        emprestimos.add(new Emprestimo(187, 2, LocalDate.MIN, LocalDate.EPOCH, false, 0));
       
        String op = JOptionPane.showInputDialog("1- Login\n 2- Listar Usuarios\n 3-Buscar livro pelo id\n 4- Listar todos os livros");
        if(op.contains("1")){
            
           String verLogin = JOptionPane.showInputDialog("Insira o E-mail");
           String verSenha = JOptionPane.showInputDialog("Insira a senha");
           
           for(Usuario f : usuarios){
            if(f.getEmail().contains(verLogin) && f.getSenha().contains(verSenha)){
                System.out.println(":D");
                
                 int verEmp = Integer.parseInt(JOptionPane.showInputDialog("1- Livros não entregues\n 2- Livros entregues"));
                 if(verEmp == 1){
                     for(Emprestimo r : emprestimos){
                         if(r.isDevolvido() == false && r.getIdUsuario() == f.id){
                             JOptionPane.showMessageDialog(null, "Livro(s) não entregue\ncod.: " + r.getIdLivro());
                         }
                     }
                 }
                 else if(verEmp == 2){
                     for(Emprestimo r : emprestimos){
                         if(r.isDevolvido() == true && r.getIdUsuario() == f.id){
                             JOptionPane.showMessageDialog(null, "Livro(s) entregue\ncod.: " + r.getIdLivro());
                         }
                     }
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "Comando inválido!!");
                 }
            }
            else{
                JOptionPane.showMessageDialog(null, "O E-mail informado não existe!!");
            }
           }         
        }
        
        else if(op.contains("2")){
            for(Usuario f : usuarios){
                JOptionPane.showMessageDialog(null, f.getNome() + " : " + f.getId());
            }
        }
        else if(op.contains("3")){
            int verLivro = Integer.parseInt(JOptionPane.showInputDialog("Insira codigo do livro"));
            for(Livros g : livros){
                if(verLivro == g.getId()){
                    System.out.println(":D");
                    JOptionPane.showMessageDialog(null, g.getTitulo() +
                            "\n" + 
                            g.getAutor() +
                            "\n" + 
                            g.getEditora() +
                            "\n" + 
                            g.getEdicao() +
                            "\n" + 
                            g.getCidade() +
                            "\n" + 
                            g.getAnopublicacao());
                }
                else{
                    JOptionPane.showMessageDialog(null, "Codigo do livro não existe");
                }
            }
        }
        else if(op.contains("4")){
            for(Livros g : livros){
                JOptionPane.showMessageDialog(null, g.toString());
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "Comando invalido");
        }
        
        
        
            
    }
}
