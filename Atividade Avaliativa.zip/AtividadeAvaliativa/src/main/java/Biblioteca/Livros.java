
package Biblioteca;


public class Livros extends Biblioteca{
    private String titulo;
    private String autor;
    private String edicao;
    private String editora;
    private String cidade;
    private int anopublicacao;

    public Livros() {
    }

    public Livros(String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao, int id) {
        super(id);
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
        this.anopublicacao = anopublicacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEdicao() {
        return edicao;
    }

    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getAnopublicacao() {
        return anopublicacao;
    }

    public void setAnopublicacao(int anopublicacao) {
        this.anopublicacao = anopublicacao;
    }

    
    @Override
    public int getId() {
        return super.id;
    }
    
    @Override
    public String toString() {
        return "titulo: " + titulo + "\nautor: " + autor + "\nedicao: " + edicao + "\neditora: " + editora + "\ncidade: " + cidade + "\nano de publicacao: " + anopublicacao + "\ncod.: " + super.id;
    }
    
    
    
    
    
}
