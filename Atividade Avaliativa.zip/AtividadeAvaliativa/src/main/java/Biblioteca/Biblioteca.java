
package Biblioteca;

public abstract class Biblioteca {
    protected int id;

    public Biblioteca() {
    }

    public Biblioteca(int id) {
        this.id = id;
    }
    
    public abstract int getId();

    @Override
    public String toString() {
        return "ID: " + getId() + "\n";
    }
    
    
    
}
